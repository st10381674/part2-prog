﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FINALPART22.Data;
using FINALPART22.Models;

namespace FINALPART22.Controllers
{
    public class ClaimApprovalsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimApprovalsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ClaimApprovals
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.ClaimsApprovals
                .Include(c => c.AcademicManager)
                .Include(c => c.Claim)
                .Include(c => c.ProgrammeCoordinator);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: ClaimApprovals/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var claimApproval = await _context.ClaimsApprovals
                .Include(c => c.AcademicManager)
                .Include(c => c.Claim)
                .Include(c => c.ProgrammeCoordinator)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (claimApproval == null)
            {
                return NotFound();
            }

            return View(claimApproval);
        }

        // GET: ClaimApprovals/Create
        public IActionResult Create()
        {
            ViewData["AcademicManagerId"] = new SelectList(_context.AcademicManagers, "Id", "Name");
            ViewData["ClaimId"] = new SelectList(_context.Claims, "Id", "Programme");
            ViewData["ProgrammeCoordinatorId"] = new SelectList(_context.ProgrammeCoordinators, "Id", "Name");
            return View();
        }

        // POST: ClaimApprovals/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ClaimId,ProgrammeCoordinatorId,AcademicManagerId,Status,Comments,DateOfAction")] ClaimApproval claimApproval)
        {
            if (ModelState.IsValid)
            {
                _context.Add(claimApproval);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AcademicManagerId"] = new SelectList(_context.AcademicManagers, "Id", "Name", claimApproval.AcademicManagerId);
            ViewData["ClaimId"] = new SelectList(_context.Claims, "Id", "Programme", claimApproval.ClaimId);
            ViewData["ProgrammeCoordinatorId"] = new SelectList(_context.ProgrammeCoordinators, "Id", "Name", claimApproval.ProgrammeCoordinatorId);
            return View(claimApproval);
        }

        // GET: ClaimApprovals/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var claimApproval = await _context.ClaimsApprovals.FindAsync(id);
            if (claimApproval == null)
            {
                return NotFound();
            }
            ViewData["AcademicManagerId"] = new SelectList(_context.AcademicManagers, "Id", "Name", claimApproval.AcademicManagerId);
            ViewData["ClaimId"] = new SelectList(_context.Claims, "Id", "Programme", claimApproval.ClaimId);
            ViewData["ProgrammeCoordinatorId"] = new SelectList(_context.ProgrammeCoordinators, "Id", "Name", claimApproval.ProgrammeCoordinatorId);
            return View(claimApproval);
        }

        // POST: ClaimApprovals/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ClaimId,ProgrammeCoordinatorId,AcademicManagerId,Status,Comments,DateOfAction")] ClaimApproval claimApproval)
        {
            if (id != claimApproval.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(claimApproval);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClaimApprovalExists(claimApproval.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw; // Consider logging this exception
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AcademicManagerId"] = new SelectList(_context.AcademicManagers, "Id", "Name", claimApproval.AcademicManagerId);
            ViewData["ClaimId"] = new SelectList(_context.Claims, "Id", "Programme", claimApproval.ClaimId);
            ViewData["ProgrammeCoordinatorId"] = new SelectList(_context.ProgrammeCoordinators, "Id", "Name", claimApproval.ProgrammeCoordinatorId);
            return View(claimApproval);
        }

        // GET: ClaimApprovals/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var claimApproval = await _context.ClaimsApprovals
                .Include(c => c.AcademicManager)
                .Include(c => c.Claim)
                .Include(c => c.ProgrammeCoordinator)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (claimApproval == null)
            {
                return NotFound();
            }

            return View(claimApproval);
        }

        // POST: ClaimApprovals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var claimApproval = await _context.ClaimsApprovals.FindAsync(id);
            if (claimApproval != null)
            {
                _context.ClaimsApprovals.Remove(claimApproval);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClaimApprovalExists(int id)
        {
            return _context.ClaimsApprovals.Any(e => e.Id == id);
        }
    }
}
