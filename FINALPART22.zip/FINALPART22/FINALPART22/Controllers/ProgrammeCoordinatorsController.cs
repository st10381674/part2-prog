﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FINALPART22.Data;
using FINALPART22.Models;

namespace FINALPART22.Controllers
{
    public class ProgrammeCoordinatorsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProgrammeCoordinatorsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ProgrammeCoordinators
        public async Task<IActionResult> Index(string searchString)
        {
            var programmeCoordinators = from pc in _context.ProgrammeCoordinators
                                        select pc;

            if (!String.IsNullOrEmpty(searchString))
            {
                programmeCoordinators = programmeCoordinators.Where(pc => pc.Name.Contains(searchString) || pc.Email.Contains(searchString));
            }

            return View(await programmeCoordinators.ToListAsync());
        }

        // GET: ProgrammeCoordinators/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programmeCoordinator = await _context.ProgrammeCoordinators
                .FirstOrDefaultAsync(m => m.Id == id);
            if (programmeCoordinator == null)
            {
                return NotFound();
            }

            return View(programmeCoordinator);
        }

        // GET: ProgrammeCoordinators/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ProgrammeCoordinators/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Email,PhoneNumber")] ProgrammeCoordinator programmeCoordinator)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(programmeCoordinator);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                }
            }
            return View(programmeCoordinator);
        }

        // GET: ProgrammeCoordinators/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programmeCoordinator = await _context.ProgrammeCoordinators.FindAsync(id);
            if (programmeCoordinator == null)
            {
                return NotFound();
            }
            return View(programmeCoordinator);
        }

        // POST: ProgrammeCoordinators/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email,PhoneNumber")] ProgrammeCoordinator programmeCoordinator)
        {
            if (id != programmeCoordinator.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(programmeCoordinator);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProgrammeCoordinatorExists(programmeCoordinator.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(programmeCoordinator);
        }

        // GET: ProgrammeCoordinators/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programmeCoordinator = await _context.ProgrammeCoordinators
                .FirstOrDefaultAsync(m => m.Id == id);
            if (programmeCoordinator == null)
            {
                return NotFound();
            }

            return View(programmeCoordinator);
        }

        // POST: ProgrammeCoordinators/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var programmeCoordinator = await _context.ProgrammeCoordinators.FindAsync(id);
            if (programmeCoordinator != null)
            {
                _context.ProgrammeCoordinators.Remove(programmeCoordinator);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool ProgrammeCoordinatorExists(int id)
        {
            return _context.ProgrammeCoordinators.Any(e => e.Id == id);
        }
    }
}
