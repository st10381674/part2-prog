﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FINALPART22.Data.Migrations
{
    /// <inheritdoc />
    public partial class Approval : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ClaimsApprovals",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClaimId = table.Column<int>(type: "int", nullable: false),
                    ProgrammeCoordinatorId = table.Column<int>(type: "int", nullable: false),
                    AcademicManagerId = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfAction = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClaimsApprovals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClaimsApprovals_AcademicManagers_AcademicManagerId",
                        column: x => x.AcademicManagerId,
                        principalTable: "AcademicManagers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClaimsApprovals_Claims_ClaimId",
                        column: x => x.ClaimId,
                        principalTable: "Claims",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClaimsApprovals_ProgrammeCoordinators_ProgrammeCoordinatorId",
                        column: x => x.ProgrammeCoordinatorId,
                        principalTable: "ProgrammeCoordinators",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ClaimsApprovals_AcademicManagerId",
                table: "ClaimsApprovals",
                column: "AcademicManagerId");

            migrationBuilder.CreateIndex(
                name: "IX_ClaimsApprovals_ClaimId",
                table: "ClaimsApprovals",
                column: "ClaimId");

            migrationBuilder.CreateIndex(
                name: "IX_ClaimsApprovals_ProgrammeCoordinatorId",
                table: "ClaimsApprovals",
                column: "ProgrammeCoordinatorId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ClaimsApprovals");
        }
    }
}
