﻿

namespace FINALPART22.Models
{
    public class ClaimApproval
    {
        public int Id { get; set; }  // Primary Key for ClaimApproval

        public int ClaimId { get; set; }  // Foreign Key for Claim

        public Claim Claim { get; set; }  // Navigation Property for Claim

        public int ProgrammeCoordinatorId { get; set; }  // Foreign Key for ProgrammeCoordinator

        public ProgrammeCoordinator ProgrammeCoordinator { get; set; }  // Navigation Property for Coordinator

        public int AcademicManagerId { get; set; }  // Foreign Key for AcademicManager

        public AcademicManager AcademicManager { get; set; }  // Navigation Property for Manager

        public string Status { get; set; }  // Status of the claim (Pending, Approved, Rejected)

        public string Comments { get; set; }  // Comments on the claim (if any)

        public DateTime DateOfAction { get; set; }  // Date the action was taken
    }
}
