﻿
namespace FINALPART22.Models
{
    public class Claim
    {
        public int Id { get; set; }  // Primary Key for Claim

        public int LecturerId { get; set; }  // Foreign Key for Lecturer

        public Lecturer Lecturer { get; set; }  // Navigation Property for Lecturer

        public string Programme { get; set; }  // Program for which the claim is made

        public string Modules { get; set; }  // List of modules (or multiple module entries)

        public decimal HourlyRate { get; set; } = 79;  // Lecturer’s hourly rate

        public int HoursWorked { get; set; }  // Number of hours worked

        public decimal TotalAmount => HourlyRate * HoursWorked;  // Calculated Total Amount

        public string Document { get; set; }  // Document path or evidence file name

        public string Status { get; set; }  // Claim Status (e.g., Pending, Approved, Rejected)

        public DateTime CreatedDate { get; set; }  // Date claim was created
    }
}
