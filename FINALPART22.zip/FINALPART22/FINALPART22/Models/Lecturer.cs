﻿namespace FINALPART22.Models
{
    public class Lecturer
    {

        public int Id { get; set; }  // Primary Key for the Lecture class

        public string Name { get; set; }  // First name of the lecturer

        public string Surname { get; set; }  // Surname of the lecturer

        public string Email { get; set; }  // Email address of the lecturer

        public string PhoneNumber { get; set; }  // Phone number of the lecturer

        public string Gender { get; set; }  // Gender of the lecturer (e.g., Male, Female, etc.)

    }
}
