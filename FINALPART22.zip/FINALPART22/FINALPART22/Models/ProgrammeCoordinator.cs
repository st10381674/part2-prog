﻿namespace FINALPART22.Models
{
    public class ProgrammeCoordinator
    {
        public int Id { get; set; }  // Primary Key for ProgrammeCoordinator

        public string Name { get; set; }  // Name of the coordinator

        public string Email { get; set; }  // Email of the coordinator

        public string PhoneNumber { get; set; }  // Phone number of the coordinator
    }
}
