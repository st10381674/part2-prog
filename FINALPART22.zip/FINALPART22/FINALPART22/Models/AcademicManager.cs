﻿namespace FINALPART22.Models
{
    public class AcademicManager
    {
        public int Id { get; set; }  // Primary Key for AcademicManager

        public string Name { get; set; }  // Name of the academic manager

        public string Email { get; set; }  // Email of the academic manager

        public string PhoneNumber { get; set; }  // Phone number of the academic manager
    }
}
